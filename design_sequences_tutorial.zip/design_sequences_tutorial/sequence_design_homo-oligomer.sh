#!/bin/bash

source activate mlfold


output_dir="out_parsed_files" #change to your chosen name of the output directory 
mkdir $output_dir
input_dir="target_structure_oligomer" #change to the name of your target structure folder

path_for_parsed_chains=$output_dir"/chains.jsonl" 

path_for_tied_positions="tied_pdbs.jsonl" 

#parses the pdb file w multiple chains
python ../helper_scripts/parse_multiple_chains.py --input_path $input_dir \
    --output_path=$path_for_parsed_chains



#ties positions that have the same amino acid index across the subunits 
python ../helper_scripts/make_tied_positions_dict.py --input_path=$path_for_parsed_chains --output_path=$path_for_tied_positions --homooligomer 1

path_for_res=$output_dir"/fixed_pos.jsonl" 

#Prevent the chosen positions from being redesigned (specify fixed). All residues above conservation threshold, binding pocket.
#change the --position_list string to the "MPNN fix string" from your _constraints.csv file from the previous part (paste the list twice and separate with comma to denote both protomers of dimer), change the --chain_list to the chains of your oligomer
python ../helper_scripts/make_fixed_positions_dict.py  \
        --position_list "9 10 11 14,9 10 11 14" --chain_list "A B" \
        --input_path $path_for_parsed_chains --output_path $path_for_res

#change out_folder flag to your chosen output folder name. Change num_seq_per_target to desired value. 
python ../protein_mpnn_run.py --jsonl_path $path_for_parsed_chains \
        --omit_AAs "C" \
        --fixed_positions_jsonl $path_for_res \
        --tied_positions_jsonl $path_for_tied_positions \
        --out_folder 30_18_X_AF_designs --num_seq_per_target 11 --sampling_temp "0.1 0.3" \
        --seed 0 --batch_size 1 --save_score 1 --save_probs 1

