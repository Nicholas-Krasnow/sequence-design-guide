#!/bin/bash

#source activate mlfold


output_dir="out_parsed_files" #change to your chosen name of the output directory 
mkdir $output_dir
input_dir="target_structure" #change to the name of your target structure folder

path_for_parsed_chains=$output_dir"/chains.jsonl"

#indicate the chains of each state to design
chains_to_design="A B"

#parse the pdb file w multiple chains
python ../helper_scripts/parse_multiple_chains.py --input_path $input_dir \
    --output_path=$path_for_parsed_chains

path_for_chosen_chain=$output_dir"/chains_assigned.jsonl"

#assign the chain to design
python ../helper_scripts/assign_fixed_chains.py --input_path $path_for_parsed_chains \
        --output_path $path_for_chosen_chain --chain_list "$chains_to_design"

path_for_res=$output_dir"/fixed_pos.jsonl"

path_for_tied_positions=$output_dir"/tied_pos.jsonl"

#Prevent the chosen positions from being redesigned (specify fixed). All residues above conservation threshold, binding pocket.
#change the --position_list string to the "MPNN fix string" from your _constraints.csv file from the previous part (paste the list again, separated by a comma, for each chain to design)
python ../helper_scripts/make_fixed_positions_dict.py  \
        --position_list " , " --chain_list "$chains_to_design" \
        --input_path $path_for_parsed_chains --output_path $path_for_res

#Tie positions across chains that represent alternative states in the input PDB. Since you want one sequence to fold to both states, --position_list should have all residue numbers. Paste the list again, separated by a comma, for each chain to design
python ../helper_scripts/make_tied_positions_dict.py \
        --input_path $path_for_parsed_chains --output_path $path_for_tied_positions \
        --chain_list "$chains_to_design" --position_list " , "

#Change num_seq_per_target to desired value. 
python ../protein_mpnn_run.py --jsonl_path $path_for_parsed_chains \
        --omit_AAs "C" \
        --chain_id_jsonl $path_for_chosen_chain --fixed_positions_jsonl $path_for_res --tied_positions_jsonl $path_for_tied_positions \
        --out_folder $output_dir --num_seq_per_target 5 --sampling_temp "0.1 0.3" \
        --seed 0 --batch_size 1 --save_score 1 --save_probs 1


