#!/bin/bash

source activate mlfold


output_dir="18A_30_parsed_files" #change to your chosen name of the output directory 
mkdir $output_dir
input_dir="target_structure" #change to the name of your target structure folder

path_for_parsed_chains=$output_dir"/X_AF.jsonl" #change to your chosen name for parsed chain output

#parses the pdb file w multiple chains
python ../helper_scripts/parse_multiple_chains.py --input_path $input_dir \
    --output_path=$path_for_parsed_chains

path_for_chosen_chain=$output_dir"/X_AF_assigned.jsonl" #change to your chosen name for chosen chain output

#assigns the chain to design
python ../helper_scripts/assign_fixed_chains.py --input_path $path_for_parsed_chains \
        --output_path $path_for_chosen_chain --chain_list "A" #change if designing a different chain

path_for_res=$output_dir"/X_AF_fixed_pos.jsonl" #change to chosen name of fixed positions output

#Prevent the chosen positions from being redesigned (specify fixed). All residues above conservation threshold, binding pocket.
#change the --position_list string to the "MPNN fix string" from your _constraints.csv file from the previous part
python ../helper_scripts/make_fixed_positions_dict.py  \
        --position_list "1 5 6 8 9 10 11 12 13 15 16 18 20 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 45 46 47 48 49 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 74 75 76 77 79 80 81 82 84 86 87 88 89 91 92 93 95 96 97 101 102 104 106 108 109 111 112 113 114 115 116 118 119 120 121 122 123 124 125 126 129 130 131 132 133 134 135 136 137 138 142 144 146 147 148 149 150 151 152 153 154 155 156 157 158 159 160 161 162 163 164 165 166 167 168 169 170 171 172 173 174 175 176 177 178 179 180 181 182 183 184 185 186 187 188 189 190 191 192 193 194 195 196 197 198 201 204 205 206 207 208 209 210 212 214 215 216 217 218 219 220 221 222 223 224 225 226 227 228 229 230 231 232 233 234 235 236 237 238 239 240 241 242 243 244 245 246 247 248 249 250 251 252 253 254 255 256 257 258 259 260 261 262 263 264 265 266 267 268 269 270 271 272 273 274 275 276 277 278 280 282 284 285 286 288 292 293 294 298 301 302 303 305 309 314 316 318 321 326 331 335 337 342 343 346 347 348 349 350 351 352 355 357 359 360 361 362 363 364 365 366 367 368 370 371 372 373 375 377 378 379 382 386 387 388 389 390 391 392 398 400 401 408 410 411 418 419 420 421 422 423 424 431 436 437 438 439" --chain_list "A" \
        --input_path $path_for_parsed_chains --output_path $path_for_res

#change out_folder flag to your chosen output folder name. Change num_seq_per_target to desired value. 
python ../protein_mpnn_run.py --jsonl_path $path_for_parsed_chains \
        --omit_AAs "C" \
        --chain_id_jsonl $path_for_chosen_chain --fixed_positions_jsonl $path_for_res \
        --out_folder 30_18_X_AF_designs --num_seq_per_target 11 --sampling_temp "0.1 0.3" \
        --seed 0 --batch_size 1 --save_score 1 --save_probs 1

